# Do not expose your Neon credentials to the browser

PGHOST='ep-aged-wildflower-a55fg20w.us-east-2.aws.neon.tech'
PGDATABASE='PaletteOfBooksDB'
PGUSER='PaletteOfBooksDB_owner'
PGPASSWORD='vWsIE8NxCJd6'
ENDPOINT_ID='ep-aged-wildflower-a55fg20w'
